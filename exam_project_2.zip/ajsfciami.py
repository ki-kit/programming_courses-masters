#Name: KITA Kika

#i might have misunderstood the assignemnt and did a few points using a list i have created with a function
#(i have included the parts that used the list here but its separated from the final one with a # just in case :D)

import Node

#root = Node.Node(8)

#order-sensitive list of numbers to be considered as data in the BST
#root.insert(3)
#root.insert(6)
#root.insert(10)
#root.insert(7)
#root.insert(4)
#root.insert(14)
#root.insert(1)
#root.insert(13)

#______________________________________________________________________________
#(a)
# primes: 2, 3, 5, 7, 11, 13, 17, 19, 23

root = Node.Node(13)

root.insert(11)
root.insert(7)
root.insert(17)
root.insert(3)
root.insert(5)
root.insert(23)
root.insert(2)
root.insert(19)
#______________________________________________________________________________




#______________________________________________________________________________
#PREVIOUS VERSION
#function used in (c) and (e)-(h)  
#def print_(node):                                #defines the function as:
#    if node is not None:                         #if a node exists we want to print out its value in the following way:
#        numbers_tree = []                        #creates an empty list to store the numbers defined above
#        numbers_tree.extend(print_(node.left))   #firts iterate over the left side of the treeand add each trree element into the list in the upwards direction of the tree nodes
#        numbers_tree.extend(print_(node.right))  #then the exact same process but now for the right part of the tree
#        numbers_tree.append(node.data)           #adds the current data at the end of the list
#        return numbers_tree                      #returns us the list after the previous operations have been performed
#    else:
#        return []                                #returns nothing if the node doesnt exist   

#numbers = print_(root)                           #assigns variable to the list of numbers

#(c)                                                           
#print("the entries in the BST are:")
#print(numbers)                                   #prints out the list of numbers


#(e)&(f)
#numbers.sort()                                   #orders the numbers from the smallest entry to the greatest one

#print("the ordered list is:")
#print(numbers)

#minumum = numbers[0]                             #marks the first number in the ordered list as the smallest
#print("the smallest entry is:", minumum)         #prints out the smallest entry

#numberLeaves = len(numbers)                      #number of leaves
#maximum = numbers[numberLeaves-1]                #since list of numbers has the 1st spot marked with the number 0 we have to substract 1 from the total amount of leaves to get the greates entry
#print("the greatest entry is:", maximum)         #we print out the greatest entry


#print("the number of leaves is:", numberLeaves)  #prints out the number of leaves



#(h)
#SUM = sum(numbers)                               #sums all the entries from the previously created ordered list
#print("the sum of all entries is = ", SUM)       #prints out the sum of all entries

#(i)
#element = 8                                      #value that will serve as border between gr8ter values and smaller ones
#index = numbers.index(element)                   #find index of the value above in the orderred list
#print(index)
#print(numbers[index])


#numbers_greater_than = numbers[index+1:]         #sublist consisting of numbers strictly greater than the specified value
#print(numbers_greater_than)


#sumGreaterThan = sum(numbers_greater_than)       #sum ao all the numbers in the previously defined sublist
#print(sumGreaterThan)                            #print the sum defined above
#______________________________________________________________________________




#______________________________________________________________________________
#(b) is a separate .txt file

#______________________________________________________________________________
#(c)

#the tree structure we will print out 

def print_tree(node, level=0):
    if node is not None:
        print_tree(node.right, level + 1)        #adds one level to the rigth
        print(" -->  " * level + str(node.data))
        print_tree(node.left, level + 1)         #adds one level to the left

print("the tree structure is:\n ")
print_tree(root)
#______________________________________________________________________________


#just to keep the output more clear
print("")



#______________________________________________________________________________
#(d)

#the intention is the following:
    #define hight as the number of "arrows" connecting the root to a specific node
        #for a tree without any data we have the height set to -1 because there is no "arrow"
        #a tree with only the root will then have h=0 because of no "arrows" going out of the tree

def height_(node):
    if node is None:                           
        return -1
    else:                                        #recursive computation of the height of the left&right half of the tree
        left_height = height_(node.left)
        right_height = height_(node.right)
        return max(left_height, right_height) +1    #compares the final height of the left&right half and returns the greatest value of the two heights

height = height_(root)
print("(d)")
print("height of the tree is:", height)
#______________________________________________________________________________



#just to keep the output more clear
print("")



#______________________________________________________________________________
#(e)

#recursively looks throught the left(since that is the half of the tree that is defined to have smaller values than the root) "arrows" until there are no more left "arrows" to go through
#from all the data in the nodes it then finds the smallest entry which shall be our minimum value

def minimum_(node):
    if node is None:                #in case of an empty tree
        return None
    elif node.left is None:         #in case of no more left "arrows"
        return node.data            #returns the value of the current node=minimum
    else:
        return minimum_(node.left)  #recursively looks through the left "arrows" until it reaches the last left "arrow"

#for maximal value we will go through the right "arrows" since that is the half of the tree with values greater than the root value
#just replace the left with right & smallest with greatest in the definition of minimum_

def maximum_(node):
    if node is None:
        return None
    elif node.right is None:
        return node.data
    else:
        return maximum_(node.right)
    

min_ = minimum_(root)
max_ = maximum_(root)

print("(e)")
print("the smallest entry is:", min_)
print("the greatest entry is:", max_)
#______________________________________________________________________________



#just to keep the output more clear
print("")



#______________________________________________________________________________
#(f)

def numberLeaves(node):
    if node is None:
        return 0                #in case of an empty tree/there is no node to either left or right
    else:
        return 1 + numberLeaves(node.left) + numberLeaves(node.right)
            #when there is a node we add 1 to the leaves counter and then recursivelly cound the nodes to the left&rigth

#if there exists a node we will add 1 to the leaves counter for the current node and then recursivelly use the function on the left&right subtrees&it will run until there are no more subtrees/nodes 


leaf = numberLeaves(root)
print("(f)")
print("number of leaves is:", leaf)
#______________________________________________________________________________



#just to keep the output more clear
print("")



#______________________________________________________________________________
#(g)

#the intention is to find a path by showing the "turns" to get to the node, as in if we should move from the current node down to the left or to the right

#we use the path value to track the specific "turns" taken to reach the current/desired node, its set to none so we can start with clean slate
def find_(root, value, path=None):
    if root is None:
        return None                     

    if root.data == value:              #if our desired vlaue is found then:
        return path                     #gives us the path to get to the desired value

    if value < root.data:               #if the desired value is < than the current value there will be a left "turn" added to the path&we will look through the left side
        return find_(root.left, value, path + "L") if path else find_(root.left, value, "L")
            #if we have already taken some "turns" we               if we have not yet taken any "turns" we will recursivelly use 
            #will recursivelly use the function on                  the function on the left tree, root.left=current node&
            #the left side of the tree(roo.left=current node        &L becomes the initial "turn"
            #path+L indicates adding the "turn" taken at 
            #this poin to the already existing path
    else:                               
        return find_(root.right, value, path + "R") if path else find_(root.right, value, "R")
    #analogically as with the previous command but now there will be a right "turn" added  if the desired value is >= than the current value 


#function that utilises the output of the previous function to then give us the output=location of the desired value if it exists in the tree or if it doesnt exist in the tree at all
def find_where(root, value):
    path = find_(root, value)
    if path is None:                                    #the desired value isnt in the tree
        return print("(g) \nnode with the value", value, "is not found in this tree")
    else:                                               #for when the desired value is in the tree
        return print("(g) \nnode with the value", value, "is found at the position:", path)

ellement = 5
location = find_where(root, ellement)
#______________________________________________________________________________



#just to keep the output more clear
print("")



#______________________________________________________________________________
#(h)

#basically the same approach as in (f) but not adding 1 to the counter but the actual value inside the node
def Sum(node):
    if node is None:
        return 0
    else:
        return node.data + Sum(node.left) + Sum(node.right)


SUM = Sum(root)
print("(h)")
print("the sum of all entries is:", SUM)
#______________________________________________________________________________



#just to keep the output more clear
print("")



#______________________________________________________________________________
#(i)

def sumGr8erThan(node, element):
    if node is None:
        return 0                                            #if there is no node add 0 to the sum

    sum_gr8er = 0                                           #initial conditions in order to start summation from 0

    if node.data > element:                                 #compares the value of the current node with the value we selected
        sum_gr8er += node.data                              #if the current nodes value is greatere than the value selected by us itt will be added to sum_gr8er

#recursively use sumGr8erThan on left&right subtree
    sum_gr8er += sumGr8erThan(node.left, element)
    sum_gr8er += sumGr8erThan(node.right, element)

    return sum_gr8er                                        #the final sum of all the numbers>element 


element_val = 2                                                #our chosen value
SumGr8er = sumGr8erThan(root, element_val)

print("(i)")
print("the sum of all numbers greater than", element_val, "is:", SumGr8er)


#the structure xyz = some_function(root) is just a way to apply the function to the roots and subsequently printing the xyz variable
